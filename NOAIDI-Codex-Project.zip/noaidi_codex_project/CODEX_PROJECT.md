# NOAIDI — website project handoff for Codex

## Goal
Continue developing a premium handmade frame-drum website from this project folder.
The current priority is the **Ukrainian version**. After it is approved, create a Finnish version from the same design system.

## Important terminology
Use these terms consistently in Ukrainian:
- **бубон** — product name
- **обід** — NOT “рамка” when referring to the wooden hoop/rim
- **ясен** — NOT “береза” for the wooden rim material
- **повсть** — preferred Ukrainian word instead of “войлок”

Do not change the physical design of the drum shown in the photos.

## Visual direction
Preserve the premium minimal Nordic/editorial look from `assets/ukraine-homepage-concept.png`:
- warm ivory / natural paper background
- dark bark-brown typography
- elegant serif display headings + clean sans-serif body text
- large natural photography
- generous whitespace
- no fake mystical symbols added to the drum
- avoid visual clutter and generic e-commerce styling

The original PDF concept is in `assets/original-site.pdf`.
The latest Ukrainian visual direction is in `assets/ukraine-homepage-concept.png`.

## Ukrainian homepage structure

### Header
Brand: `NOAIDI`
Navigation:
- Бубни
- Виготовлення
- Про інструмент
- Замовити
- Контакт

### Hero
Eyebrow:
`РУЧНА РОБОТА · ПІВНІЧНА ТРАДИЦІЯ`

H1:
`Кожен бубон має свій живий голос`

Body:
`Натуральна шкіра, ясен і уважна ручна робота. Авторський рамковий бубон, створений повільно, чесно й з повагою до матеріалу.`

CTA:
`ПЕРЕГЛЯНУТИ БУБОНИ`

Small note:
`Доставка в Україну`

### Manufacturing section
Label:
`ВИГОТОВЛЕННЯ`

H2:
`Відібрано в природі, зібрано вручну`

Body:
`Обід гнеться з добірного ясеня, шкіра натягується вручну, а кожен інструмент проходить повільний шлях від матеріалу до звучання.`

Specs:
- `ОБІД — ясен`
- `МЕМБРАНА — натуральна шкіра`
- `ШНУРУВАННЯ — сиром’ятні смужки`
- `КОЛОТУШКА — дерево та м’яка повсть`
- `ТЕРМІН ВИГОТОВЛЕННЯ — 6–8 тижнів`

### Instrument section
Label:
`ПРО ІНСТРУМЕНТ`

H2:
`Теплий звук, природна форма`

Body:
`Легкий обід, жива мембрана і зручний хват формують інструмент, з яким хочеться працювати довго й уважно.`

Captions:
- Вид спереду
- Вид ззаду
- Деталь ручки

### Size / lifestyle section
Label:
`РОЗМІР І ХАРАКТЕР`

H2:
`Живий інструмент для особистої практики`

Body:
`Бубон зручно тримати в руках, використовувати для медитативної гри, ритмічних практик та камерних подій.`

### CTA
H2:
`Замовити бубон`

Body:
`Напишіть, щоб уточнити діаметр, тип шкіри, термін виготовлення та доставку в Україну.`

Buttons:
- `ЗАМОВИТИ`
- `INSTAGRAM`

Footer:
`© 2026 · Зроблено вручну в північній Скандинавії`

## Photo mapping
Use the supplied originals; do not regenerate them.

- `photo-01-process-frame.jpeg` — wooden ash rim/hoop + hide + strips; process/detail section
- `photo-02-workbench.jpeg` — full process/workbench; strong manufacturing image
- `photo-03-person-scale.jpeg` — person holding drum; size / human-scale section
- `photo-04-back-detail.jpeg` — finished rear side, black lacing, handle, beater
- `photo-05-back-lifestyle.jpeg` — rear side in forest
- `photo-06-front-vertical.jpeg` — clean front view, vertical composition
- `photo-07-back-simple.jpeg` — simpler rear view / natural branch handle
- `photo-08-handle-closeup.jpeg` — close-up of rear wooden handle
- `photo-09-front-top.jpeg` — front view with beater on greenery; preferred hero/product image
- `photo-10-front-tree.jpeg` — angled finished product photo near tree; product/detail section

## Implementation brief for Codex
Build a real responsive website from this design.

Preferred implementation if no existing stack is present:
- semantic HTML5
- modern CSS with CSS custom properties
- minimal vanilla JavaScript only where needed
- mobile-first responsive layout
- accessible buttons, navigation and alt text
- optimized images (`srcset`, lazy loading below the fold)
- no heavy framework unless the existing project already uses one

Suggested initial files:
- `index.html`
- `styles.css`
- `script.js`
- `assets/` (already included)

### Design constraints
1. Desktop should closely follow `ukraine-homepage-concept.png`.
2. Mobile should preserve the editorial hierarchy instead of simply stacking oversized desktop blocks.
3. Keep photographs uncropped where important product details would be lost; use `object-position` deliberately.
4. Maintain strong text contrast; do not reproduce the overly pale low-contrast text from the old PDF.
5. The user will later request a Finnish localization. Keep all visible strings easy to localize.
6. Do not invent prices or claims that are not confirmed.
7. Do not present the maker as Sámi or make unsupported claims of authentic Sámi cultural ownership/tradition.

## First Codex task
Inspect this folder, then create the first working Ukrainian homepage implementation based on `assets/ukraine-homepage-concept.png` and the supplied original photos. Preserve the wording and terminology above. Before changing the content model or visual direction, keep the current approved concept as the baseline.
